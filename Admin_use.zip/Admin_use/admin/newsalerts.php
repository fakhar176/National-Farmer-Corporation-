<?php  include('../config.php'); 
$price="";
?>
<?php  include(ROOT_PATH . '/admin/includes/admin_functions.php'); ?>
<?php include(ROOT_PATH . '/admin/includes/head_section.php'); ?>
<!-- Get all topics from DB -->
<?php $news = getAllNews();	?>
	<title>Admin | News Alerts </title>
</head>
<body>
	<!-- admin navbar -->
	<?php include(ROOT_PATH . '/admin/includes/navbar.php') ?>
	<div class="container content">
		<!-- Left side menu -->
		<?php include(ROOT_PATH . '/admin/includes/menu.php') ?>

		<!-- Middle form - to create and edit -->
		<div class="action">
			<h1 class="page-title">Update News Alerts</h1>
			<form method="post" action="<?php echo BASE_URL . 'admin/newsalerts.php'; ?>" >
				<!-- validation errors for the form -->
				<?php include(ROOT_PATH . '/includes/errors.php') ?>
				<!-- if editing topic, the id is required to identify that topic -->
				<?php if ($isEditingTopic === true): ?>
					<input type="hidden" name="news_id" value="<?php echo $news_id; ?>">
				<?php endif ?>
				<input type="text" name="price" value="<?php echo $price; ?>" placeholder="price">
				<!-- if editing topic, display the update button instead of create button -->
				<?php if ($isEditingTopic === true): ?> 
					<button type="submit" class="btn" name="update_news">UPDATE</button>
				<?php else: ?>
					<!--<button type="submit" class="btn" name="create_topic">Save </button>-->
				<?php endif ?>
			</form>
		</div>
		<!-- // Middle form - to create and edit -->

		<!-- Display records from DB-->
		<div class="table-div">
			<!-- Display notification message -->
			<?php include(ROOT_PATH . '/includes/messages.php') ?>
			<?php if (empty($news)): ?>
				<h1>No Seeds in the Database.</h1>
			<?php else: ?>
				<table class="table">
					<thead>
						<th>N</th>
						<th>Seeds Name</th>
						<th>Date</th>
						<th>Price</th>
						<th colspan="2">Action</th>
					</thead>
					<tbody>
					<?php foreach ($news as $key => $new): ?>
						<tr>
							<td><?php echo $key+1; ?></td>
							<td><?php echo $new['name']; ?></td>
							<td><?php echo $new['date']; ?></td>
							<td><?php echo $new['price']; ?></td>
							<td>
								<a class="fa fa-pencil btn edit"
									href="newsalerts.php?edit-news=<?php echo $new['id'] ?>">
								</a>
							</td>
							<td>
								<a class="fa fa-trash btn delete"								
									href="newsalerts.php?insert-news=<?php echo $new['id'] ?>">
								</a>
							</td>
						</tr>
					<?php endforeach ?>
					</tbody>
				</table>
			<?php endif ?>
		</div>
		<!-- // Display records from DB -->
	</div>
</body>
</html>
