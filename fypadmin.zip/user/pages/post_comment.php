<?php 
include("../process/check-login - pages.php"); 
$post_id=$query_class_object->real_escape($_GET['postes']); 
 
 $query_class_object->session_value('post_id',$post_id);


?>




<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Blank Page</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../assets/vendor/bootstrap/css/bootstrap.min.css">
    <link href="../assets/vendor/fonts/circular-std/style.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/libs/css/style.css">
    <link rel="stylesheet" href="../assets/vendor/fonts/fontawesome/css/fontawesome-all.css">
</head>

<body>
    <!-- ============================================================== -->
    <!-- main wrapper -->
    <!-- ============================================================== -->
    <div class="dashboard-main-wrapper">
         <!-- ============================================================== -->
        <!-- navbar -->
        <!-- ============================================================== -->
        <div class="dashboard-header">
            <nav class="navbar navbar-expand-lg bg-white fixed-top">
                <a class="navbar-brand" href="../index.php"><img src="../assets/images/logo.png" alt=""></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto navbar-right-top">
                        <li class="nav-item">
                            <div id="custom-search" class="top-search-bar">
                                <input class="form-control" type="text" placeholder="Search..">
                            </div>
                        </li>
                        <li class="nav-item dropdown notification">
                            <a class="nav-link nav-icons" href="#" id="navbarDropdownMenuLink1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><i class="fas fa-fw fa-bell"></i> <span class="indicator"></span></a>
                            <ul class="dropdown-menu dropdown-menu-right notification-dropdown">
                                <li>
                                    <div class="notification-title"> Notification</div>
                                    <div class="notification-list">
                                        <div class="list-group">
                                            <a href="#" class="list-group-item list-group-item-action active">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-2.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">Jeremy Rakestraw</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-3.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">John Deo</span>is now following you
                                                        <div class="notification-date">2 days ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-4.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">Monaan Pechi</span> is watching your main repository
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                            <a href="#" class="list-group-item list-group-item-action">
                                                <div class="notification-info">
                                                    <div class="notification-list-user-img"><img src="../assets/images/avatar-5.jpg" alt="" class="user-avatar-md rounded-circle"></div>
                                                    <div class="notification-list-user-block"><span class="notification-list-user-name">Jessica Caruso</span>accepted your invitation to join the team.
                                                        <div class="notification-date">2 min ago</div>
                                                    </div>
                                                </div>
                                            </a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="list-footer"> <a href="#">View all notifications</a></div>
                                </li>
                            </ul>
                        </li>
                       
                        <li class="nav-item dropdown nav-user">
                            <a class="nav-link nav-user-img" href="#" id="navbarDropdownMenuLink2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="./../process/profile/<?php echo($profile_pic);?>" alt="profile" class="user-avatar-md rounded-circle"  style="width:40px;height:40px;"></a>
                            <div class="dropdown-menu dropdown-menu-right nav-user-dropdown" aria-labelledby="navbarDropdownMenuLink2">
                                <div class="nav-user-info">
                                    <h5 class="mb-0 text-white nav-user-name"><?php echo strtoupper ($profile_name); ?></h5>
                                    <span class="status"></span><span class="ml-2">Available</span>
                                </div>
                                <a class="dropdown-item" href="../profile.php"><i class="fas fa-user mr-2"></i>Account</a>
                                <a class="dropdown-item" href="profile_complete.php"><i class="fas fa-cog mr-2"></i>Setting</a>
                                <a class="dropdown-item" href="../process/logout-process.php"><i class="fas fa-power-off mr-2"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
        <!-- ============================================================== -->
        <!-- end navbar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- left sidebar -->
        <!-- ============================================================== -->
       <?php include("left_slide.php"); ?>
                 
        <!-- ============================================================== -->
        <!-- end left sidebar -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- wrapper  -->
        <!-- ============================================================== -->
        <div class="dashboard-wrapper">
           
   
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                         
						  
                          <div class="card border-3 border-top border-top-primary">
                              <div class="card-body">
                                    <h2 class="text-center" style="transform:30px;"> <span class="badge badge-brand"><h1>Public Comment Section!</h1></span></h2>
                          <?php 
						  
						  $qury="SELECT p.id,p.user_id, p.title, p.slug, p.views, p.image, p.body, p.published      ,p.created_at, p.updated_at,u.id, u.username FROM posts As p INNER JOIN users As u ON  p.id='$post_id' and p.user_id=u.id and p.published=true ORDER BY p.user_id DESC";
						  
						  $path='../../Admin_use/static/images/';
						  $result =$query_class_object->query_result($qury);
                                foreach($result as $row){ 
								
								?>


                                <div class="row">
                            <!-- ============================================================== -->
                            <!-- product sales  -->
                            <!-- ============================================================== -->
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                <div class="card">
                                    <div class="card-header">
                                        <div class="float-right">
                                                <h5 class="mb-0"> <?php echo $row['updated_at'];?> </h5>
                                            </div>
                                        <h5 class="mb-0"><?php echo $row['slug'];?>  Post</h5>
                                    </div>
                                    <div class="card-body" style="padding-left:90px;">
                                
                                  <img src="<?php echo $path.$row['image'];?>"  class="img-thumbnail" alt="Cinque Terre" width="804" height="736" > 


                                    </div>
                                </div>
                            </div>

                        </div>

                                   <div style="border:double; padding:30px;">
                                      <p align="left"><span class="badge badge-success">Post By <?php echo $row['username'];?></span></p> 
                                        <div align="center" > <h2><?php echo  strtoupper ($row['title']);?></h2> <?php echo $row['body'];?> </div>
                                   
                                   </div>
                                   
                                   <?php }?>
                               </div>
                            </div>
                      </div>
                </div>
            
              <!-- ============================================================== -->
            <!--  reply Form -->
            <!-- ============================================================== -->
            
            
            
            
            
            
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                      <div class="card">
                                <h5 class="card-header">Comment </h5>
                      
                      
                      <?php 
					  $query="SELECT id, user_id,user_name,comment,date  FROM comment WHERE post_id='$post_id'";
					   $results =$query_class_object->query_result($query);

                                foreach($results as $row){ 
								          $user_id=$row['user_id'];
                                           $uid=$row['id'];
								?> 
					           

                                <div style="padding-right:200px;">
                               <p align="right"><span class="badge badge-success"> <?php echo $row['date'];?></span></p>
                                  
                                  <div style="border:double; padding:10px;">
                                        <p align="left">
                                            <span class="badge badge-info">Post By <?php echo $row['user_name'];?> </span>

                                        </p>
                                          <?php if($cutomer_id==$user_id){


                                         echo "<p align='right'><a href='../process/delete_comment.php?commentid=$uid'><i class='fa fa-trash'></a></i></p>";

                                        }?> 
                                         <p align="right">
                                             <span class="badge badge-info" >
                                                <button onclick="funct(<?php echo $uid; ?>)">Reply</button>
                                             </span>
                                            
                                        </p>

                                         <div align="center" ><?php echo $row['comment'];?> </div>
                                   </div>
                                     
                                     </div>
                                    

                      <?php 
                     
                      $query1="SELECT Replyer_name,Reply,date  FROM comment_reply WHERE post_id='$post_id' and comment_id='$uid'";
                       $results =$query_class_object->query_result($query1);

                                foreach($results as $row1){ ?>

                                     
                                   
                                    <div style="padding-left:150px; padding-right: 100px;">
                                        <p align="right"><span class="badge badge-success"> <?php echo $row1['date'];?></span></p>

                                        
                                         <div style="border:double; padding:10px;">
                                        <p align="left">
                                            <span class="badge badge-info">Reply By <?php echo $row1['Replyer_name'];?> </span>

                                        </p>



                                       <div align="center" ><?php echo $row1['Reply'];?> </div>
                                   </div>


                                   
                                   </div> 



                            <?php    }

                             } ?>
                    
                       </div>
                    </div>
               </div>
            </div>
            
            <!-- ============================================================== -->
            <!--  reply Form -->
            <!-- ============================================================== -->
           

            <script type="text/javascript">
                function funct(value){

                    var valu=value;
                    
                    var comment_id=document.getElementById("comment_id");
                    comment_id.value=valu;
                   
                 $(document).ready(function(){ 
                           $('#NewInvoiceNumber').modal('toggle');

                        


                       });









                }
                

            </script> 




             <div class="col-lg-12">
                        <div class="modal fade" id="NewInvoiceNumber" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                <div class="modal-dialog" style="width:315px">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                           <!--  <h4 class="modal-title" id="H4"> Reply </h4> -->
                                        </div>
                                        <div class="modal-body">
                                           <form role="form" action='../process/comment -reply.php' method="post" enctype="multipart/form-data">
                                          
                                           <div class="form-group">
                                            <label>Give Reply</label>
                                            <input type="hidden" name="comment_id" id="comment_id">
                                            <input type="hidden" name="post_id" id="post_id" value="<?php echo $post_id; ?>">
                                            <textarea rows = "2" cols = "30" name = "description" class="form-control" id="validationCustom03" placeholder=" Enter Comment..." required></textarea>
                                            <p class="help-block">Save To Add Reply.</p>
                                        </div>
                                            
                                            <button type="submit" name="Savereply" id="Savereply" class="btn btn-primary">Save</button>
                                            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                        
                                       
                                            </form>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                    </div>




<!-- <script type="text/javascript">
$('#SaveInvoice').click(function(){

     
 var invoice=document.getElementById("InvoiceNumber").value;

   var request =$.ajax
     ({   
       url:'Execute/ExInvoiceIncrement.php',
       async:false ,
       method:'post', 
       data: {invoice:invoice},
        dataType:'html' 
        
        });

        // request.done(function( msg ) 
        // {
        //    //alert(msg);

        //   // location.href='./Invoice.php?id= '+invoice;


        // });

});

</script> -->























          <!-- ============================================================== -->
            <!-- Comment Form -->
            <!-- ============================================================== -->
            
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    
                        <div class="card">
                                <h5 class="card-header">Information Form</h5>
                                    <div class="card-body">
                                    
                                    <form  action='../process/comment.php' method="post" enctype="multipart/form-data">
                                    
                                   
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                    <input type="hidden" name="post_id" id="post_id"  value="<?php echo $post_id;?>">                                          <label for="validationCustom01">Name </label>
                                                <input type="text" class="form-control" id="validationCustom01" 
                                                 placeholder="name"  name="name"  required>
                                                <div class="valid-feedback">
                                                    Looks good!
                                                </div>
                                            </div>
                                            
                                            
                                            
                                            
                                      <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mb-2">
                                                <label for="validationCustom04">Comment</label>
                                                 <textarea rows = "2" cols = "30" name = "description" class="form-control" id="validationCustom03" placeholder=" Enter Comment..." required></textarea>
                                                <div class="invalid-feedback">
                                                    Please provide a valid state.
                                                </div>
                                            </div>
                        
                        
                         <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                                      <button class="btn btn-primary" type="submit"  id="comment_sumit" name="comment_sumit"> Post Comment</button>
                                            </div>
                        
                        
                                      </form>
                                      </div>
                               </div>            
                       
                    
                    
                    
                    
                    </div>
                 </div>
             </div>
            
            
            
            
            
            
  
            
            
            
            
            <!-- ============================================================== -->
            <!-- Comment Form -->
            <!-- ============================================================== -->





            <!-- ============================================================== -->
            <!-- footer -->
            <!-- ============================================================== -->
            
            
            
            
            <div class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            2018 © Influence - Designed and Developed by<a href="https://themeforest.net/user/jitu/portfolio" target="_blank" class="ml-1">Jituchuahan</a>.
                        </div>
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="text-md-right footer-links d-none d-sm-block">
                                <a href="javascript: void(0);">About</a>
                                <a href="javascript: void(0);">Support</a>
                                <a href="javascript: void(0);">Contact Us</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ============================================================== -->
            <!-- end footer -->
            <!-- ============================================================== -->
        </div>
    </div>
    </div>
    
    <!-- ============================================================== -->
    <!-- end main wrapper -->
    <!-- ============================================================== -->
    <!-- Optional JavaScript -->
    <script src="../assets/vendor/jquery/jquery-3.3.1.min.js"></script>
    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.js"></script>
    <script src="../assets/vendor/slimscroll/jquery.slimscroll.js"></script>
    <script src="../assets/libs/js/main-js.js"></script>
</body>

</html>