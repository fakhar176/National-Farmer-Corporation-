<?php
include("lib/mysqli-query.php");
$query_class_object->session_str();
if(($query_class_object->session_check('user_id') &&  $query_class_object->session_value('user_id')!="")   && 
($query_class_object->session_check('user_name') &&  $query_class_object->session_value('user_name')!="")  && 
($query_class_object->session_check('cnic') &&  $query_class_object->session_value('cnic')!="")&& 
($query_class_object->session_check('role') &&  $query_class_object->session_value('role')!="")  )
{
	
	 $cutomer_id=$query_class_object->session_value('user_id');
	  $profile_pic=$query_class_object->session_value('profile');
	   $profile_name=$query_class_object->session_value('user_name');
	     $cutomer_cnic=$query_class_object->session_value('cnic');
	      // $Role=$query_class_object->session_value('role');



	       
 $quer="select frist_name, last_name, gender, email, contect, address, city, zip ,Role,approved
	           from user where id='$cutomer_id' and cnic='$cutomer_cnic' and username='$profile_name' ";
    
      $result=$query_class_object->query_result($quer);
	  list($frist_name, $last_name, $gender, $email, $contect, $address, $city, $zip ,$Role,$approved)=$query_class_object->fetch_array($result);
	
}
else
{
	 header("location: pages/login.php");
	
}






?>
