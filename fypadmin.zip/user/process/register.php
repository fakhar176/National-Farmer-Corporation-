<?php
include("../lib/mysqli-query.php");


$query_class_object->session_str();

if(isset($_POST['submit']))
{
$user_name=$query_class_object->real_escape($_POST['nick']);
$cnic=$query_class_object->real_escape($_POST['cnic']);
$Role=$query_class_object->real_escape($_POST['role']);
$password=$query_class_object->real_escape($_POST['password']);
$password=md5($password);


 $qury="INSERT INTO user
     (id,profile, username,frist_name,last_name,gender,cnic, email,contect, address,city, zip, Role,approved,password, date, status)
		 VALUES 
     ('','profile.png','$user_name','not_define','not_define','not_define','$cnic','email@gmail.com','0301-1234-567','Enter address ....','not_define','not_define','$Role','No','$password',now(),'1')";

 if($query_class_object->insert_query($qury,"false"))
    {
      $query1="select id,profile, username,cnic,Role 
	           from user where 
			   username ='$user_name' and  password='$password' and cnic='$cnic'";
    
      $result=$query_class_object->query_result($query1);
	  list($user_id,$profile,$user_name,$cnic,$Role)=$query_class_object->fetch_array($result);
	


	  $query_class_object->session_value('user_id',$user_id);
	   $query_class_object->session_value('profile',$profile);
	  $query_class_object->session_value('user_name',$user_name);
	  $query_class_object->session_value('cnic',$cnic);
	  $query_class_object->session_value('role',$Role);

	  header("location: ./index.php");
   }

   else{
   	 header("location: ../pages/Error_page.php? id='Sign_Up  Error'");
       

   }

  

}


?>


