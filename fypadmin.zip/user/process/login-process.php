<?php
include("../lib/mysqli-query.php");


$query_class_object->session_str();

if(isset($_POST['submit']))
{
$user_name=$query_class_object->real_escape($_POST['username']);
$password=$query_class_object->real_escape($_POST['password']);
$password=md5($password);

$query="select id,username from user where password='$password' and (username='$user_name' OR cnic= '$user_name') ";


if($query_class_object->check_rows($query)==1)
{
	$query1="select id,profile,username,cnic,Role from user where password='$password' and (username='$user_name' OR cnic= '$user_name')";
	$result=$query_class_object->query_result($query1);
    list($user_id,$profile,$user_name ,$cnic,$Role)=$query_class_object->fetch_array($result);
	
	$query_class_object->session_value('user_id',$user_id);
	$query_class_object->session_value('profile',$profile);
	$query_class_object->session_value('user_name',$user_name);
    $query_class_object->session_value('cnic',$cnic);
	$query_class_object->session_value('role',$Role);
	
	
	header("location: ./index.php");

}
else
{
	header("location: ../pages/login.php?msg=incorrect");
	
}	
	
}	



?>
