<?php include("../../lib/mysqli-query.php"); 

$query_class_object->session_str();
$id=$_GET['id'];
$query_class_object->session_value('user_id',$id);
 header("location: ../../pages/update_client_profile.php");
?>
