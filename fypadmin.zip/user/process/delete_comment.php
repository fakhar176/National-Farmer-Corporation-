<?php
include("../lib/mysqli-query.php");


$query_class_object->session_str();
$qury_checker=0;
$id=$query_class_object->session_value('user_id');
 $profile_name=$query_class_object->session_value('user_name');
 
  $post_id=$query_class_object->session_value('post_id');

 if(isset($_GET['commentid']))
{


$comment_id=$query_class_object->real_escape($_GET['commentid']);




$query="DELETE FROM comment WHERE id='$comment_id' and post_id='$post_id' ";
$query1="DELETE FROM comment_reply WHERE comment_id='$comment_id' and post_id='$post_id' ";


 $query_class_object->delete_query($query,"false");
 $query_class_object->delete_query($query1,"false");

 header("location: ../pages/post_comment.php? postes=$post_id");
}
?>