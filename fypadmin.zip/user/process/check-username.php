<?php
include("../lib/mysqli-query.php");
if(isset($_POST['user_name']) && $_POST['user_name']!="" && $_POST['cnic']!="")
{
    $check_username=0;
    $user_name_check="";
	
	$user_name= $query_class_object->real_escape($_POST['user_name']);
	$cnic= $query_class_object->real_escape($_POST['cnic']);
	
	$query="select  username from user where username='$user_name'";
    $query1="select  cnic from user where cnic='$cnic' ";
	
	  $user_name_check=$query_class_object->select_single_value($query);
	  $check_cnic=$query_class_object->select_single_value($query1);
	
	if($user_name_check!="")
	  {
	   $check_username=1;
	  }
	else if($check_cnic!="")
	 {
	   $check_username=2;
	 }
	else
	 {
	  $check_username=0;	
	 }
	echo $check_username;
}


 else{
   	 header("location: ../pages/Error_page.php? id='User Name Error'");
       

   }


?>