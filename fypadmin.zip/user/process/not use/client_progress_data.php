<?php
include("../lib/mysqli-query.php");


$query_class_object->session_str();
$customer_id=$query_class_object->session_value('user_id');
if(isset($_POST['cahng_progress']))
{
   $post=$query_class_object->real_escape($_POST['post']);
    $likes=$query_class_object->real_escape($_POST['likes']);
     $comments=$query_class_object->real_escape($_POST['comments']);
      $engagement=$query_class_object->real_escape($_POST['engagement']);
       $media=$query_class_object->real_escape($_POST['media']);
          $link=$query_class_object->real_escape($_POST['link']);
           $date=$_POST['date'];
		    
			 
			$qury="UPDATE total_record SET post='$post',engagement='$engagement',likes='$likes',comments='$comments',media_value='$media',link_clicks='$link'  WHERE customer_id='$customer_id' and date='$date'";
			  $query_class_object->update_query($qury,"false");
                 header("location: ../pages/update_client_profile.php");
		   
		   
}


if(isset($_POST['insert_sumit']))
{
   $post=$query_class_object->real_escape($_POST['post1']);
    $likes=$query_class_object->real_escape($_POST['likes1']);
     $comments=$query_class_object->real_escape($_POST['comments1']);
      $engagement=$query_class_object->real_escape($_POST['engagement1']);
       $media=$query_class_object->real_escape($_POST['media1']);
          $link=$query_class_object->real_escape($_POST['link1']);
           //$date=$_POST['date'];
		   
		  $qury1=" INSERT INTO total_record(id,customer_id,post,engagement,likes, comments, media_value, link_clicks, date, status) VALUES ('','$customer_id','$post','$engagement','$likes','$comments','$media','$link',now(),'1')";
		  $query_class_object->insert_query($qury1,"false");
                 header("location: ../pages/update_client_profile.php");

}


if(isset($_POST['profile_sumit']))
{
$username=$query_class_object->real_escape($_POST['username']);
$Email=$query_class_object->real_escape($_POST['Email']);
$f_name=$query_class_object->real_escape($_POST['f_name']);
$l_name=$query_class_object->real_escape($_POST['l_name']);
$contect=$query_class_object->real_escape($_POST['contect']);


$city=$query_class_object->real_escape($_POST['city']);
$state=$query_class_object->real_escape($_POST['state']);
$zip=$query_class_object->real_escape($_POST['zip']);


$qury3="UPDATE customer_record SET f_name='$f_name', l_name='$l_name', username='$username', email='$Email', contect='$contect', city='$city', state='$state', zip ='$zip' WHERE id='$customer_id'";
             $query_class_object->update_query($qury3,"false");
                 header("location: ../pages/update_client_profile.php");

}



?>
