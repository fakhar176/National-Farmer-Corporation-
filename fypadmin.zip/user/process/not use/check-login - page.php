<?php
include("../lib/mysqli-query.php");
$query_class_object->session_str();


if(($query_class_object->session_check('user_id') &&  $query_class_object->session_value('user_id')!="")   && 
($query_class_object->session_check('user_name') &&  $query_class_object->session_value('user_name')!="")  )
{
	
	$profile_name=$query_class_object->session_value('user_name');
	 $cutomer_id=$query_class_object->session_value('user_id');
                     
								
}
else
{
	header("location: pages/login.php");
	
}






?>
