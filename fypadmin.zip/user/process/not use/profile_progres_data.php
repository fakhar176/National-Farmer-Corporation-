<?php 
include("../lib/mysqli-query.php");
$query_class_object->session_str();

$cutomer_id=$query_class_object->session_value('user_id');
if(isset($_POST['date']))
{
	$date=$_POST['date'];
	$qury1="SELECT post,engagement,likes,comments, media_value,link_clicks FROM total_record WHERE  customer_id='$cutomer_id' and date='$date'"; 
		    $result =$query_class_object->query_result($qury1);
            foreach($result as $row)
			{
				$post=$row['post'];
				$engagement=$row['engagement'];
				$likes=$row['likes'];
				$comments=$row['comments'];
				$media_value=$row['media_value'];
				$link_clicks=$row['link_clicks']; 
			 
			}
			
			echo $post.'/'.$engagement.'/'.$likes.'/'.$comments.'/'.$media_value.'/'.$link_clicks.'/';
}
?>	