<?php
include("../lib/mysqli-query.php");


$query_class_object->session_str();
$qury_checker=0;
$id=$query_class_object->session_value('user_id');
 $profile_name=$query_class_object->session_value('user_name');


if(isset($_POST['profile_sumit']))
{

$profile=$query_class_object-> upload_picture($_FILES['profile']['name'],$_FILES['profile']['type'],$_FILES['profile']['tmp_name'],"./profile/");


$f_name=$query_class_object->real_escape($_POST['f_name']);
$l_name=$query_class_object->real_escape($_POST['l_name']);
$gender=$query_class_object->real_escape($_POST['gender']);
$cnic=$query_class_object->real_escape($_POST['cnic']);
$email=$query_class_object->real_escape($_POST['email']);
$contect=$query_class_object->real_escape($_POST['contect']);
$Address=$query_class_object->real_escape($_POST['description']);
$city=$query_class_object->real_escape($_POST['city']);
$zip=$query_class_object->real_escape($_POST['zip']);
$role=$query_class_object->real_escape($_POST['role']);

    if($profile!=''){
       $query_class_object->session_value_unset('profile');
        $profile_pic=$query_class_object->session_value('profile',$profile);
    }else{
    	$profile=$query_class_object->session_value('profile');
    }



$qury="UPDATE user SET  profile='$profile', frist_name='$f_name',last_name='$l_name',gender='$gender',
email='$email',contect='$contect',address='$Address',city='$city',zip='$zip',Role='$role'  WHERE id='$id' and username='$profile_name' and  cnic='$cnic'";

        

           $query_class_object->update_query($qury,"false");
        header("location: ../index.php");

}










if(isset($_POST['password_sumit']))
{

$email=$query_class_object->real_escape($_POST['email']);
$oldpassword=$query_class_object->real_escape($_POST['oldpassword']);
$oldpassword=md5($oldpassword);
$newpassword=$query_class_object->real_escape($_POST['password']);
$newpassword=md5($newpassword);
$id=$query_class_object->session_value('user_id');

$qury="UPDATE user SET password='$newpassword'  WHERE id='$id' and email='$email' and  password='$oldpassword' ";

          $query_class_object->update_query($qury,"false");
           header("location: ../index.php"); 


}












if(isset($_POST['cahng_email']))
{

$email=$query_class_object->real_escape($_POST['email']);
$password=$query_class_object->real_escape($_POST['password']);
$password=md5($password);
$newemail=$query_class_object->real_escape($_POST['remail']);

$id=$query_class_object->session_value('user_id');

$qury1=" UPDATE user SET email='$newemail'  WHERE id='$id' and password='$password' and email='$email' and username='$profile_name'"; 
                  
 if($query_class_object->update_query($qury1,"False")!=true)
 {
	header("location: ../index.php"); 
}
	else {
		header("location: ../pages/Error_page.php? id='Email not change please Try again'");
 }


}




?>


