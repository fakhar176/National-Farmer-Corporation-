<?php
include("../lib/mysqli-query.php");

$query_class_object->session_str();
$id=$query_class_object->session_value('user_id');
$profile_name=$query_class_object->session_value('user_name');


if(isset($_POST['submit']))
{

$image=$query_class_object-> upload_picture($_FILES['image']['name'],$_FILES['image']['type'],$_FILES['image']['tmp_name'],"../../Admin_use/static/images/");

$topics=$query_class_object->real_escape($_POST['topics']);

$title=$query_class_object->real_escape($_POST['title']);
$editordata=$query_class_object->real_escape($_POST['editordata']);

$query="INSERT INTO posts(user_id, title, slug, views, image, body, published, created_at, updated_at) VALUES('$id','$title','$topics','0',
'$image','$editordata','0',now(),now())";

    $query_class_object->insert_query($query,"false");

      header("location: ../index.php");

      

echo "$topics";
echo "$title";
echo "$editordata";


}
?>