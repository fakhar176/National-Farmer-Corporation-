<?php
include("../lib/mysqli-query.php");


$query_class_object->session_str();
$qury_checker=0;
$id=$query_class_object->session_value('user_id');
 $profile_name=$query_class_object->session_value('user_name');

 if(isset($_POST['comment_sumit']))
{


$name=$query_class_object->real_escape($_POST['name']);
$description=$query_class_object->real_escape($_POST['description']);

$post_id=$query_class_object->real_escape($_POST['post_id']);



$query="INSERT INTO comment( post_id, user_id, user_name, comment, date, status) VALUES ('$post_id','$id','$name','$description',now(),'1')";
 $query_class_object->insert_query($query,"false");
 header("location: ../pages/post_comment.php? postes=$post_id");
}
?>