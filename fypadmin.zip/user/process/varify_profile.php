
<?php
include("../lib/mysqli-query.php");


$query_class_object->session_str();
$qury_checker=0;
$id=$query_class_object->session_value('user_id');
 $profile_name=$query_class_object->session_value('user_name');


if(isset($_POST['email']) && $_POST['email']!="" && $_POST['password']!="")
{
    $check_username=0;
    $user_info_check="";
	
	$email= $query_class_object->real_escape($_POST['email']);
	$password= $query_class_object->real_escape($_POST['password']);
	$password=md5($password);
	 $query1="select username from user where password='$password' and email='$email' and username='$profile_name'";
	
	  $user_info_check=$query_class_object->select_single_value($query1);
	
	if($user_info_check!="")
	  {
	   $check_username=1;
	  }else
	 {
	  $check_username=0;	
	 }
	echo $check_username;
}
?>