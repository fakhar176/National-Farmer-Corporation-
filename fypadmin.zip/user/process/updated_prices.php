<?php
//include("lib/mysqli-query.php");
//$query_class_object->session_str();
if(($query_class_object->session_check('user_id') &&  $query_class_object->session_value('user_id')!="") )
{	
   $sead_id = array();
	 $sead_name = array();
	 $sead_price = array();
	  $Sead_discription = array();
	  $date =  array();

	 $count=0;

// $quer="SELECT `id`, `seedid`, `price`, `date` FROM `seedsratehistory` WHERE 1";
    
    $query2="SELECT id,name,description, date,price FROM seedprice ";
   
      $result =$query_class_object->query_result($query2);
                       foreach($result as $row){
                       	$count++;
                        $sead_id[$count]=$row['id'];
                       	$sead_name[$count]=$row['name'];
                       	 $sead_price[$count]= $row['price'];
                          $Sead_discription[$count] = $row['description'];
                            $date[$count] = $row['date'];
                       }

     $querye2="SELECT  price,AVG(price)/SUM(price) FROM seedsratehistory WHERE seedid='$sead_id[1]'";
           $resulte2=$query_class_object->query_result($querye2);
                  list($cotton_price,$cotton_price_avg)=$query_class_object->fetch_array($resulte2);  



     $query2="SELECT  price,AVG(price)/SUM(price) FROM seedsratehistory WHERE seedid='$sead_id[2]'";
           $result2=$query_class_object->query_result($query2);
                  list($rice_price,$rice_price_avg)=$query_class_object->fetch_array($result2);  




     $query3="SELECT  price, AVG(price)/SUM(price) FROM seedsratehistory WHERE seedid='$sead_id[3]'";
           $result3=$query_class_object->query_result($query3);
                  list($wheat_price,$wheat_price_avg)=$query_class_object->fetch_array($result3);  



     $query4="SELECT  price,AVG(price)/SUM(price) FROM seedsratehistory WHERE seedid='$sead_id[4]'";
           $result4=$query_class_object->query_result($query4);
                  list($sugercane_price,$sugercane_price_price_avg)=$query_class_object->fetch_array($result4);  






	
}
else
{
	 header("location: pages/login.php");
	
}






?>
