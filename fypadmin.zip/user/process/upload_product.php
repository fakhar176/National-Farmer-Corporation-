<?php
include("../lib/mysqli-query.php");

$query_class_object->session_str();
$id=$query_class_object->session_value('user_id');
$profile_name=$query_class_object->session_value('user_name');


if(isset($_POST['submit']))
{



$image1=$query_class_object-> upload_picture($_FILES['image1']['name'],$_FILES['image1']['type'],$_FILES['image1']['tmp_name'],"../../Admin_use/static/images/product/");
$image2=$query_class_object-> upload_picture($_FILES['image2']['name'],$_FILES['image2']['type'],$_FILES['image2']['tmp_name'],"../../Admin_use/static/images/product/");
$image3=$query_class_object-> upload_picture($_FILES['image3']['name'],$_FILES['image3']['type'],$_FILES['image3']['tmp_name'],"../../Admin_use/static/images/product/");


    $image = array ($image1,$image2,$image3);
       $images =implode(" , ", $image); 
       //echo $images;


//$title=($_POST['title']);

$title=implode(", ", $_POST['title']);
//echo $title;


$type=$query_class_object->real_escape($_POST['type']);

$Quality=$query_class_object->real_escape($_POST['Quality']);


 $KG=$query_class_object->real_escape($_POST['KG']);
  $MAUND=$query_class_object->real_escape($_POST['MAUND']);

  $kg_mun = array ($KG,$MAUND);
       $kg_mund =implode(" , ", $kg_mun); 

   $GUNNY=$query_class_object->real_escape($_POST['GUNNY']);



  $minprice=$query_class_object->real_escape($_POST['minprice']);
  $mixprice=$query_class_object->real_escape($_POST['mixprice']);
  
  $price_limi = array ($minprice,$mixprice);
       $price_limit =implode(" , ", $price_limi); 
  
 

  $Location=$query_class_object->real_escape($_POST['Location']);

   
   $contact=$query_class_object->real_escape($_POST['contact']);
   $editordata=$query_class_object->real_escape($_POST['editordata']);




$query="INSERT INTO `product`(`id`, `product_title`, `product_type`, `quality`, `kg_mund`, `gunny`, `price_limit`, `location`, `contact`, `description`, `images`, `saler`,`saler_id`, `date`, `status`) VALUES ('','$title','$type','$Quality','$kg_mund','$GUNNY','$price_limit','$Location','$contact','$editordata','$images','$profile_name','$id',now(),'0')";


     if ($query_class_object->insert_query($query,"false")){
     	echo "<script type='text/javascript'>
                alert('product add succesfully');
     	  </script>";

        	header("location: ../index.php");


     }else{

     	echo "<script type='text/javascript'>
                alert('product not added succesfully');
     	  </script>";

     	   header("location: ../pages/upload_product.php");
     }

    
   

    

      

// echo "$topics";
// echo "$title";
// echo "$editordata";


}
?>