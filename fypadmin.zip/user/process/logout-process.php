<?php
include("../lib/mysqli-query.php");
$query_class_object->session_str();
if(($query_class_object->session_check('user_id') &&  $query_class_object->session_value('user_id')!="")   && 
($query_class_object->session_check('user_name') &&  $query_class_object->session_value('user_name')!="")  )
{
 	$query_class_object->session_value_unset('user_id');
 	$query_class_object->session_value_unset('profile');
 	$query_class_object->session_value_unset('user_name');
	$query_class_object->session_value_unset('cnic');
	$query_class_object->session_value_unset('role');
	$query_class_object->session_value_unset('post_id');

    $query_class_object->session_end();
	header("location: ../pages/login.php");
}
else
{
	header("location: ../pages/login.php");
}
?>