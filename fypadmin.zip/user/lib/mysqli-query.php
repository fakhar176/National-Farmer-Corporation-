<?php
class query_class
{ 
 
    public $local_host="localhost";
	public $database_name="mix";
	public $username="root";
	public $password=""; 
	public $count1=0;
	public $insert_id="";
        
      
   
   
    function real_escape($permeter)
	{
			$connetion= mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name) or die (mysql_error());  
			$string=$connetion->real_escape_string($permeter);  
			mysqli_close($connetion);
			return $string;		
	}
	
	function string_sanitize($string) 
	{
		$result = preg_replace("/[^a-zA-Z0-9]+/", " ", html_entity_decode($string, ENT_QUOTES));
		return $result;
	}
	
	function insert_query($query,$msg)
	{
			$connetion=mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name)or die("connetion fail ...");
			mysqli_query($connetion,$query)or die("query is incorrect ...".mysql_error());
			$insert_id=mysqli_insert_id($connetion); 
 			if($msg==true)
			{
			 echo "data save successfuly..";		 
			}
			mysqli_close($connetion);
			return $insert_id;		
	}
	
	function update_query($query,$msg)
	{
		$connetion=mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name)or die("connetion fail ...");
		
		mysqli_query($connetion,$query)or die("query is incorrect ...".mysql_error());
		
		if($msg==true)
		{
		 echo "data update successfuly..";
		}
		else{
			return "not correct";	
			}
		
		mysqli_close($connetion);
	   	
	   
	}
	function delete_query($query,$msg)
	{
		$connetion=mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name)or die("connetion fail ...");
		mysqli_query($connetion,$query)or die("query is incorrect ...".mysql_error());
		if($msg==true)
		{
		 echo "data delete successfuly..";
		}
		mysqli_close($connetion);	
	}
	
	function logic_check($query,$user_name,$password,$array_string)
	{
        //error_reporting(E_ALL | E_STRICT);
        //ini_set('display_errors', 'On');
        $this->session_str();
	    $check=0; 
        $connetion= mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name) or die (mysql_error());  
        $user_name = $this->real_escape($user_name); 
        $password = $this->real_escape($password); 
        $password=md5($password);        
        $statment = $connetion->prepare($query) or die (mysql_error()); 
        $statment->bind_param('ss', $user_name,$password);        
        $statment->execute();
        $statment->bind_result($uid,$uname);
        while($statment->fetch())
        {   
          if($uid!="" && $uname!="")
		  {   
             $check=1;  
            $this->session_value(''.$array_string[0],$uid);
            $this->session_value(''.$array_string[1],$uname);
		  }
        }
        return $check;
	}
	
	function pic_code_check($query,$pin_code,$array_string)
	{
		$this->session_str();
	    $check=0; 
        $connetion= mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name) or die (mysql_error());  
        $pin_code = $this->real_escape($pin_code); 
		$pin_code=md5($pin_code);
        $statment = $connetion->prepare($query) or die (mysql_error()); 
        $statment->bind_param('s', $pin_code);        
        $statment->execute();
        $statment->bind_result($settings_id);
		while($statment->fetch())
        {   
		  if($settings_id!="")
		  {   
             $check=1;  
             $this->session_value(''.$array_string[0],$settings_id);
		  }
        }
		return $check;
	}
	
    function check_rows($query)
	{
	    $check=0; 
	    $connetion=mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name)or die("connetion fail ...");
		$results=mysqli_query($connetion,$query)or die("query is incorrect ...".mysql_error());
        while($rows=mysqli_fetch_array($results))
		{			  
		  if($rows[0]!="")
		  {
		   $check=1;
		  }
		}
        mysqli_close($connetion);
		return $check;	
	}
	function select_single_value($query)
	{
	    $value="";
		$connetion=mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name)or die("connetion fail ...");
		$results=mysqli_query($connetion,$query)or die("query is incorrect ...".mysql_error());
        while($rows=mysqli_fetch_array($results))
		{		  
		  if($rows[0]!="")
		  {
		   $value=$rows[0];
		  }
		}		
		mysqli_close($connetion);
		return $value;	
	}
	function select_query($query,$font_style_sheet,$action_style_sheet,$color_one,$color_two,$edit,$delete,$maximum_record)
	{
	  
	  echo "<script language='javascript' type='text/javascript'>function del_Record(Link){var x = confirm('Do you want to Delete this Record.'); if(x == true)
	  {	window.location = Link;}}</script>";
	    
	    $check=0;
		$connetion=mysql_connect($this->local_host,$this->username,$this->password)or die("connetion fail ...");
		mysql_select_db($this->database_name,$connetion)or die("database name is incorrect ...");
		
		$results_1=mysql_query($query,$connetion)or die("query is incorrect ...");
		$record= mysql_num_rows($results_1);
		$display_record=3;		
		$pages=ceil($record/$display_record);
	    //$query_1=$query;
		if(isset($_GET['page_number']))
		{
		 $last_record=$_GET['last_record'];
		 echo  $last_record;
		 $query.="limit $last_record,$display_record";
		}
		//else
		//{
		 //$query_1.="limit 0,$display_record";
		//}
		
		
		$results=mysql_query($query,$connetion)or die("query is incorrect ...");		   
	    
		
		$column_count=mysql_num_fields($results);		
		$column_count_paging=0;
		$column_count_paging= $column_count+1;
	    $last_record=0;
		
		
		if($record>0)
		{
			while($rows=mysql_fetch_array($results))
			{
			  $last_record=$rows[$maximum_record]; 		  
			  if($check==0)
			  {
			   echo "<tr bgcolor='$color_one'>";
			   $check=1;
			  }
			  else if($check==1)
			  {
				echo "<tr bgcolor='$color_two'>";
				$check=0;		  
			  }
			  for($count=0;$count< $column_count;$count++)
			  {
			   echo "<td class='$font_style_sheet'>".$rows[$count] ."</td>";		  
			  }		  	
			  echo "<td align='center'>";	  
			  if($edit!="")
			  {
					$count=0;
					$link="";				
					$increment=4;
					foreach($edit as $value)
					{
						if($count==$increment)
						{
							$increment=$increment+4;
							$link.=$rows[$value];
						}
						else
						{
							$link.=$value;
						}
						$count++;
					}
					echo "<a href='$link' class=$action_style_sheet>Edit</a>";
			  }			  
			  if($delete!="")
			  {
					echo "&nbsp;&nbsp;";
					$count=0;
					$link="";					
					$increment=4;
					foreach($delete as $value)
					{
						if($count==$increment)
						{
							$increment=$increment+4;
							$link.=$rows[$value];
						}
						else
						{
							$link.=$value;
						}
						$count++;
					}
					?>				
					<a href="javascript: del_Record('<?php echo $link; ?>');" class="<?php echo $action_style_sheet;?>">Delete</a>
			  <?php
			  }		  
			  echo "</td></tr>";
			}			
			echo "<tr><td align='center' colspan='$column_count_paging'>";
			for($count=1;$count<=$pages;$count++)
			{
			  echo "<a href='index.php?page_number=$count&last_record=$last_record' class=$action_style_sheet>$count&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>";			
			}
			echo "</td></tr>";
			
		}
		else
		{
		 echo "<tr><td align='center' colspan='$column_count_paging'>No Record</td></tr>";		
		}

		mysql_close($connetion);
	}   
	function query_result($query)
	{
	    $connetion=mysqli_connect($this->local_host,$this->username,$this->password,$this->database_name)or die("connetion fail ...");
		//mysql_select_db($this->database_name,$connetion)or die("database name is incorrect ...");
		$results=mysqli_query($connetion,$query)or die("query is incorrect ...".mysql_error());	
		mysqli_close($connetion);
		return $results;
	}
	function query_num_rows_count($result)
	{
	  return mysqli_num_rows($result);
	}
	function fetch_array($result)
	{	  
	  return mysqli_fetch_array($result);
	}
	function session_str()
    {
	  session_start();
	}
	function session_check($name)
	{
	  if(isset($_SESSION[$name]))
	  {
	    return 1;
	  }
	  else
	  {
	   return 0;
	  }
	}
	function session_value($name,$value='')
	{
	     if($value!="")
		 {
		  $_SESSION[$name]=$value;
		 }		 
		 else
		 {
		   return $_SESSION[$name];
		 }
	}
	function session_value_unset($name)
	{    
		  $_SESSION[$name]="";
		  unset($_SESSION[$name]);
	}
	function session_end()
	{
	  session_unset();
	  session_destroy();
	}
	
	function show_picture($image,$file,$width,$height)
	{
	    define("SHOW_PIC", "thumbnail.php");
		$img_src ="";
		$file=$file.$image;
		if(file_exists($file) && !empty($image))
		{
			$file = base64_encode($file);			
			$i_widht = base64_encode($width);			
			$i_height = base64_encode($height);											
			$img_src = SHOW_PIC."?img=".$file."&mw=".$i_widht."&mh=".$i_height;
		}
		else
		{
			$file = NO_IMAGE;
			$file = base64_encode($file);
			$i_widht = base64_encode($width);
			$i_height = base64_encode($height);
			$img_src = SHOW_PIC."?img=".$file."&mw=".$i_widht."&mh=".$i_height;
		}
		return $img_src;
	}
	function message_box($msg)
	{
	 echo "<script  type='text/javascript'>alert('".$msg."');</script>";
	}
	function ftp_upload($ftp_query,$file_actual_name,$file_temp_name,$mode,$add_path='')
	{
	   $ftp_res=$this->query_result($ftp_query);
       list($ftp_server,$ftp_username,$ftp_password,$ftp_remote_path,$ftp_local_path,$add_date,$status)=$this->fetch_array($ftp_res);
	   $conn_id = ftp_connect($ftp_server) or die("ftp connection is fail ...");
	   ftp_login($conn_id, $ftp_username, $ftp_password) or die("ftp login is fail ...");
	   ftp_pasv($conn_id, true);
	   $ftp_result=ftp_put($conn_id, $ftp_remote_path.$add_path.$file_actual_name,$file_temp_name,$mode) or die("fail to upload file ...");
	   ftp_close($conn_id);
	   return $ftp_result;  
	}
	function ftp_delete_file($ftp_query,$file_full_path)
	{
	   $ftp_res=$this->query_result($ftp_query);
       list($ftp_server,$ftp_username,$ftp_password,$ftp_remote_path,$ftp_local_path,$add_date,$status)=$this->fetch_array($ftp_res);
	   $conn_id = ftp_connect($ftp_server) or die("ftp connection is fail ...");
	   ftp_login($conn_id, $ftp_username, $ftp_password) or die("ftp login is fail ...");
	   ftp_pasv($conn_id, true);
	   $ftp_result=ftp_delete($conn_id, $ftp_remote_path.$file_full_path)or die("ftp fail to delete ...");
	   ftp_close($conn_id);
	   return $ftp_result; 
	}
	function ftp_download($ftp_query,$file_full_path,$resource_name,$mode)
	{
	   $ftp_res=$this->query_result($ftp_query);
       list($ftp_server,$ftp_username,$ftp_password,$ftp_remote_path,$ftp_local_path,$add_date,$status)=$this->fetch_array($ftp_res);
	   $conn_id = ftp_connect($ftp_server) or die("ftp connection is fail ...");
	   ftp_login($conn_id, $ftp_username, $ftp_password) or die("ftp login is fail ...");
	   ftp_pasv($conn_id, true);
	   $ftp_result=ftp_get($conn_id,"C:\windows\temp",$ftp_remote_path.$file_full_path,$mode)or die("ftp fail to download ...");
	   ftp_close($conn_id);
	   return $ftp_result; 
	}
	function upload_picture($file_real_name,$file_type_method1,$file_temp_name,$path)
	{  
	    $file_name="";
		//$allowedExts = array("gif", "jpeg","bmp","jpg", "png");
	    //$allowed_file_type_method1=array("image/bmp","image/png","image/jpeg","image/jpg","image/gif");
	    //$allowed_file_type_method2=array("image/x-ms-bmp","image/png","image/jpeg","image/jpg","image/gif");
        $allowedExts = array("gif", "jpeg","jpg", "png");
	    $allowed_file_type_method1=array("image/png","image/jpeg","image/jpg","image/gif");
	    $allowed_file_type_method2=array("image/png","image/jpeg","image/jpg","image/gif");
	    $file_type_method2=mime_content_type($file_temp_name);
        $path_string = $file_real_name;
        $extension=strtolower(pathinfo($path_string, PATHINFO_EXTENSION));	   
			if (in_array($file_type_method1, $allowed_file_type_method1) && in_array($file_type_method2, $allowed_file_type_method2) && in_array($extension, $allowedExts))
			{
				$file_name=$this->generateRandomString().".".$extension;
				move_uploaded_file($file_temp_name,$path.$file_name);            
			}
			else
			{
				$file_name="";
			}
		    return $file_name;
	}    
    function make_thumbnails($original_path,$original_image,$thumbnail_path,$thumbnail_width,$thumbnail_height,$thumb_beforeword)
	{  
			$thumbnail_name="";
			$src=$original_path.$original_image;
			$thumbnail_name=$thumb_beforeword."_".$original_image;	
			$dest=$thumbnail_path.$thumb_beforeword."_".$original_image;
			$desired_width=$thumbnail_width;
			$desired_height=$thumbnail_height;

			$extension=strtolower(pathinfo($src, PATHINFO_EXTENSION));
			$image_Type = '';
			if($extension=="jpg" ||  $extension=="jpeg" )
			{
				$source_imageJpg = imagecreatefromjpeg($src);
				$source_image = $source_imageJpg;
				$image_Type ='jpg';
			}
			else if($extension=="png")
			{
				$source_imagePng = imagecreatefrompng($src);
				$source_image = $source_imagePng;
				$image_Type =  'png';
			}
			else if($extension=="gif")
			{
				$source_imageGif = imagecreatefromgif($src);
				$source_image = $source_imageGif;
				$image_Type = 'gif';
			}
			$width = imagesx($source_image);
			$height = imagesy($source_image);

			/* find the "desired height" of this thumbnail, relative to the desired width  */
			//$desired_height = floor($height * ($desired_width / $width));
			/* create a new, "virtual" image */
			$virtual_image = imagecreatetruecolor($desired_width, $desired_height);
			/* copy source image at a resized size */
			imagecopyresampled($virtual_image, $source_image, 0, 0, 0, 0, $desired_width, $desired_height, $width, $height);
			/* create the physical thumbnail image to its destination */
			if($image_Type =='jpg')
			{
			   imagejpeg($virtual_image,$dest,80);
			}
			else if($image_Type == 'png')
			{
			   imagepng($virtual_image,$dest,1);
			}
			else if($image_Type == 'gif')
			{
				imagegif($virtual_image,$dest);
			}
			return $thumbnail_name;
	}
	function page_name()
	{        
        $pg_name=basename($_SERVER['PHP_SELF']);
		return $pg_name;
	}
	function show_limited_text($text,$number_charactors)
	{	
		$string = $text;
		if (strlen($string) > $number_charactors) 
		{
			$string = substr($string, 0, $number_charactors).' ...'; 
		}
		else
		{
			$string=$string;
		}
		return  $string;
    }
	function file_download($path)
	{
		if(file_exists($path))
		{
			header("Content-Disposition: attachment; filename=" . urlencode($path));   
			header("Content-Type: application/force-download");
			header("Content-Type: application/octet-stream");
			header("Content-Type: application/download");
			header("Content-Description: File Transfer");            
			header("Content-Length: " . filesize($path));
			flush(); 
			$fp = fopen($path, "r");
			while (!feof($fp))
			{
				echo fread($fp, 65536);
				flush(); 
			} 
			fclose($fp);
		}
		else
		{
		 	 return false;
		}
   }
   function file_delete($path,$query)
   {
	   $picture=$this->select_single_value($query);
	   if($picture!="")
	   {
		   $full_path=$path.$picture;
		   if(file_exists($full_path))
		   {
			   unlink($full_path);
			   return true;
		   }
		   else
		   {
			  return false;
		   }
	   }
   } 
  function generateRandomString($length = 15) 
  {
    $string =substr(str_shuffle(str_repeat($x='0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length/strlen($x)) )),1,$length);      
    $string=time()."_".$string; 
    $md5_string=md5($string);
    return $md5_string;
   }    
    
   function file_upload($file_real_name,$file_type_method1,$file_temp_name,$path)
   {
        $file_name="";
		$allowedExts = array("doc","docx","xls","xlsx","ppt","pptx","pdf","txt","csv","gif", "jpeg","bmp","jpg", "png");
	   
	    $allowed_file_type_method1=array("image/bmp","image/png","image/jpeg","image/jpg","image/gif","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet","application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation","application/pdf","text/plain","text/csv");
	    
	   
	    $allowed_file_type_method2=array("image/x-ms-bmp","image/png","image/jpeg","image/jpg","image/gif","application/msword","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.ms-office","application/octet-stream","application/vnd.ms-powerpoint","application/vnd.openxmlformats-officedocument.presentationml.presentation","application/pdf","text/plain");
	   
	    $file_type_method2=mime_content_type($file_temp_name);
	   
        $path_string = $file_real_name;
        $extension=strtolower(pathinfo($path_string, PATHINFO_EXTENSION));
	   
			if (in_array($file_type_method1, $allowed_file_type_method1) && in_array($file_type_method2, $allowed_file_type_method2) && in_array($extension, $allowedExts))
			{
				$file_name=$this->generateRandomString().".".$extension;
				move_uploaded_file($file_temp_name,$path.$file_name);            
			}
			else
			{
				$file_name="";
			}
		    return $file_name;
	}
    function limitParagraphs($sHTML, $iLimit)
    {
        if(1 === preg_match('~(<p>.+?</p>){' . (int)$iLimit . '}~i', $sHTML, $aMatches))
        {
            return $aMatches[0];
        }
        return $sHTML;
    }
    
    
}
$query_class_object=new query_class();
?>