-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2019 at 01:09 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `marketing`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_record`
--

CREATE TABLE `admin_record` (
  `id` int(244) NOT NULL,
  `profile` varchar(244) NOT NULL,
  `user_name` varchar(244) NOT NULL,
  `password` varchar(244) NOT NULL,
  `name` varchar(244) NOT NULL,
  `email` varchar(244) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_record`
--

INSERT INTO `admin_record` (`id`, `profile`, `user_name`, `password`, `name`, `email`, `date`, `status`) VALUES
(1, '', 'fakhar', '202cb962ac59075b964b07152d234b70', 'Fakhar Hayat', 'mfakhar@gmail.com', '2019-09-12', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customer_record`
--

CREATE TABLE `customer_record` (
  `id` int(243) NOT NULL,
  `profile` varchar(244) NOT NULL,
  `f_name` varchar(244) NOT NULL,
  `l_name` varchar(244) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gender` varchar(244) NOT NULL,
  `contect` varchar(244) NOT NULL,
  `city` varchar(244) NOT NULL,
  `state` varchar(244) NOT NULL,
  `zip` varchar(244) NOT NULL,
  `password` varchar(244) NOT NULL,
  `prof_complete` int(244) NOT NULL,
  `date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer_record`
--

INSERT INTO `customer_record` (`id`, `profile`, `f_name`, `l_name`, `username`, `email`, `gender`, `contect`, `city`, `state`, `zip`, `password`, `prof_complete`, `date`, `status`) VALUES
(20, '114860925e5b06d54952269f17ce1e60.png', 'Ali', 'Khan', 'Ali', 'ali@gmail.com', 'Male', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-11 23:02:11.378529', '1'),
(21, 'a548e9a9920b0a47323bd14ca45b302e.png', 'Khizar', 'Hayat', 'khizar', 'khizar@gmail.com', 'Male', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-07 18:04:08.459437', '1'),
(22, 'f92cf2c77d267ea54b4dfc02a5895c2a.png', 'Fakhar', 'Hayat', 'Fakhar', 'fakhar@gmail.com', 'Male', '03420808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-10 01:17:17.721590', '1'),
(23, 'fa6df6fed588e8a5dad9ee002c89be4d.png', 'Faisal', 'Hayat', 'faisal', 'faisal@gmail.com', 'Male', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-07 18:04:19.506702', '1'),
(24, 'eb18d4664aa4ea8d56136eab24803630.png', 'Asad', 'Batool', 'Ayesha', 'Ayesha@gmail.com', 'Male', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-11 23:00:09.163375', '1'),
(31, 'd2eeb86f804360c43ba9c19674fd5fc8.png', 'ahad', 'monis', 'Ahad', 'Ahad@gmail.com', 'Male', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-07 18:03:40.949861', '1'),
(32, 'f5c832bcba33b59ab403ce574f749c38.png', 'zain', 'younis', 'Zain', 'Zain@gmail.com', 'Male', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-07 18:04:27.113105', '1'),
(33, '3990a171b998d1c4d41f513df195e15d.png', 'hassan', 'younis', 'Hassan', 'Hassan@gmail.com', 'Male', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-07 18:04:30.657308', '1'),
(34, 'c54da0174d4176e7a868f692a16a09b0.png', 'anzil', 'Batool', 'anji', 'anji@gmail.com', 'Female', '03040808926', 'Layyah', 'Punjab', '31200', '202cb962ac59075b964b07152d234b70', 100, '2019-09-07 18:03:20.406938', '1');

-- --------------------------------------------------------

--
-- Table structure for table `total_record`
--

CREATE TABLE `total_record` (
  `id` int(244) NOT NULL,
  `customer_id` int(244) NOT NULL,
  `post` int(244) NOT NULL,
  `engagement` int(244) NOT NULL,
  `likes` int(244) NOT NULL,
  `comments` int(244) NOT NULL,
  `media_value` int(244) NOT NULL,
  `link_clicks` int(244) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(244) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `total_record`
--

INSERT INTO `total_record` (`id`, `customer_id`, `post`, `engagement`, `likes`, `comments`, `media_value`, `link_clicks`, `date`, `status`) VALUES
(3, 20, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(4, 21, 1, 1, 0, 0, 0, 0, '2019-09-07', '1'),
(5, 22, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(6, 23, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(7, 24, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(14, 31, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(15, 32, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(16, 33, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(17, 34, 0, 0, 0, 0, 0, 0, '2019-09-07', '1'),
(18, 22, 101, 103, 105, 105, 104, 10, '2019-11-09', '1'),
(19, 22, 22, 2, 2, 4, 32, 3, '2019-09-09', '1'),
(20, 24, 36, 54, 34, 44, 35, 32, '2019-09-11', '1'),
(23, 20, 56, 3, 34, 23, 22, 43, '2019-09-12', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_record`
--
ALTER TABLE `admin_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_record`
--
ALTER TABLE `customer_record`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `total_record`
--
ALTER TABLE `total_record`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`) USING BTREE;

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_record`
--
ALTER TABLE `admin_record`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `customer_record`
--
ALTER TABLE `customer_record`
  MODIFY `id` int(243) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `total_record`
--
ALTER TABLE `total_record`
  MODIFY `id` int(244) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `total_record`
--
ALTER TABLE `total_record`
  ADD CONSTRAINT `total_record_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customer_record` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
